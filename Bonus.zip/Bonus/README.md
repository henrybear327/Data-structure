# Personal info

* Name: Chun-Hung Tseng
* Student ID: 403410033
* Department: Computer Science and Information Engineering
* E-tutor ID: henrybear327

# Problem list

## Solved: 37

1. AR
    * 02, 05, 08, 13, 23, 26, 27
2. BT
    * 01
3. CH
    * 03, 05, 06
4. DT
    * 01, 03, 13
5. MM
    * 04, 47, 52, 59, 61
6. RU
    * 03, 04, 05
7. SO
    * 03, 05, 10, 16, 19
8. ST
    * 02, 13, 18, 22
9. SL
    * 07, 11, 12, 24
10. OT
    * 23
11. DP
    * 03
